//
//  DiagnosticAppApp.swift
//  DiagnosticApp
//
//  Created by 菅原佑太 on 2026/01/02.
//

import SwiftUI

@main
struct DiagnosticAppApp: App {
    var body: some Scene {
        WindowGroup {
            ContentView()
        }
    }
}
